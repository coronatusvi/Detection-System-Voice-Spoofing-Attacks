# filepath: /streamlit-audio-recorder/src/demo.py

import io
import streamlit as st
from st_audiorec import st_audiorec
from voice_spoof_detection import compute_hash, get_model, run_model, AudioProcessor
import numpy as np
import torchaudio
import torch

st.set_page_config(page_title="Detection System Voice Spoofing Attacks")

def audiorec_demo_app():
    st.title('Hệ thống phát hiện tấn công giả mạo giọng nói')
    st.markdown('Implemented by [VI&HA]')
    st.write('\n\n')

    # Thu âm trực tiếp
    st.subheader("🎤 Record Audio")
    wav_audio_data = st_audiorec()

    if wav_audio_data is not None:
        # st.markdown("#### Recorded Audio")
        # st.audio(wav_audio_data, format='audio/wav')

        # Xử lý âm thanh đã thu
        audio_np = np.frombuffer(wav_audio_data, dtype=np.float32)

        # Kiểm tra dữ liệu âm thanh
        if audio_np.size == 0 or np.all(audio_np == 0):
            st.error("⚠️ Recorded audio is empty or invalid. Please try again.")
        else:
            # Xử lý âm thanh đã thu
            audio_np = np.frombuffer(wav_audio_data, dtype=np.float32)

            # Kiểm tra dữ liệu âm thanh
            if audio_np.size == 0 or np.all(audio_np == 0):
                st.error("⚠️ Recorded audio is empty or invalid. Please try again.")
                return

            # Nếu audio_np là 1D, thêm chiều cho channels
            if audio_np.ndim == 1:
                audio_np = np.expand_dims(audio_np, axis=0)

            # Nếu audio_np là stereo, chuyển sang mono
            if audio_np.shape[0] > 1:
                audio_np = np.mean(audio_np, axis=0, keepdims=True)

            # Chuẩn hóa dữ liệu về [-1, 1]
            max_val = np.max(np.abs(audio_np), axis=-1, keepdims=True)
            if max_val == 0:
                st.error("⚠️ Recorded audio is silent or invalid. Please try again.")
                return
            audio_np = audio_np / max_val

            # Giới hạn kích thước dữ liệu
            max_length = 64000  # 4 giây ở 16kHz
            if audio_np.shape[-1] > max_length:
                audio_np = audio_np[:, :max_length]

            # Chạy mô hình
            likelihood = run_model(audio_np)

            # Hiển thị kết quả với cảnh báo
            if likelihood > 70:  # Xa 0, khả năng giả mạo cao
                st.error(f"🚨 **Khả năng là giọng giả:** {likelihood:.1f}% ❗")
            elif likelihood > 40:  # Trung bình
                st.warning(f"⚠️ **Khả năng là giọng giả:** {likelihood:.1f}% ⚠️")
            else:  # Gần 0, khả năng thật cao
                st.success(f"✔️ **Khả năng là giọng giả:** {likelihood:.1f}% ✔️")

    # Tải lên file âm thanh
    st.subheader("📁 Upload Audio File")
    uploaded_file = st.file_uploader("", type=["wav", "flac", "mp3"])
    if uploaded_file is not None:
        st.markdown("#### Uploaded Audio")
        st.audio(uploaded_file, format=f"audio/{uploaded_file.name.split('.')[-1]}")

        # Đọc và xử lý file âm thanh
        audio_bytes = uploaded_file.read()
        ext = uploaded_file.name.split('.')[-1].lower()
        wav, sample_rate = torchaudio.load(io.BytesIO(audio_bytes), format=ext)

        # Nếu wav là stereo, chuyển sang mono
        if wav.shape[0] == 2:
            wav = torch.mean(wav, dim=0, keepdim=True)
        # Resample nếu cần
        if sample_rate != 16000:
            wav = torchaudio.functional.resample(wav, sample_rate, 16000)

        likelihood = run_model(wav.numpy()) 

        # Hiển thị kết quả với cảnh báo
        if likelihood > 70:  # Xa 0, khả năng giả mạo cao
            st.error(f"🚨 **Khả năng là giọng giả:** {likelihood:.1f}% ❗")
        elif likelihood > 40:  # Trung bình
            st.warning(f"⚠️ **Khả năng là giọng giả:** {likelihood:.1f}% ⚠️")
        else:  # Gần 0, khả năng thật cao
            st.success(f"✔️ **Khả năng là giọng giả:** {likelihood:.1f}% ✔️")

if __name__ == '__main__':
    audiorec_demo_app()